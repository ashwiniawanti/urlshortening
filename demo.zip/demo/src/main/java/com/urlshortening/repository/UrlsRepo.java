package com.urlshortening.repository;


import com.urlshortening.model.UrlModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface  UrlsRepo extends JpaRepository<UrlModel, Long>{
	@Query("SELECT u FROM url u WHERE u.fullUrl = ?1")
    List<UrlModel> findUrlByFullUrl(String fullUrl);
    //List<UrlModel> findAll();

}
