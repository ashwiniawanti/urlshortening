package com.urlshortening.managers;

public class UrlShortenerManger {

	 /**
     * Randomized a-z 0-9 characters. Each character appears only once in the string 
     * Base 32 string so the the Url length is limited to 6
     */
    public static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789";
    public static final int BASE = ALPHABET.length();

    /**
     * @param num Base10 number of type Long
     * @return base62 encoded string representation of input Long
     */
    public static String idToString(Long num) {
        StringBuilder str = new StringBuilder();
        while (num > 0) {
            str.insert(0, ALPHABET.charAt((int) (num % BASE)));
            num = num / BASE;
        }
        return str.toString();
    }

    /**
     * @param str Base62 encoded string
     * @return decoded Base10 number of type Long
     */
    public static Long stringToId(String str) {
        Long num = 0L;
        for (int i = 0; i < str.length(); i++) {
            num = num * BASE + ALPHABET.indexOf(str.charAt(i));
        }
        return num;
    }


}
