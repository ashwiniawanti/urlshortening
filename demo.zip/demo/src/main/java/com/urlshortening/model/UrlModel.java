package com.urlshortening.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "url")	
public class UrlModel  {
	private Long id;

    @Column(name = "full_url")
    private String fullUrl;

    @Column(name = "short_url")
    private String shortUrl;
    
    @Column
    private int numberOfRedirects = 0;

    public void setNumberOfRedirects(int numberOfRedirects) {
		this.numberOfRedirects = numberOfRedirects;
	}

	public UrlModel() {
    }

    public UrlModel(Long id, String fullUrl, String shortUrl, int numberOfredirects) {
        this.id = id;
        this.fullUrl = fullUrl;
        this.shortUrl = shortUrl;
        this.numberOfRedirects = numberOfredirects;
    }

    public UrlModel(String fullUrl) {
        this.fullUrl = fullUrl;
    }
    
    public UrlModel(String fullUrl, String shortUrl) {
        this.fullUrl = fullUrl;
        this.shortUrl = shortUrl;
    }
    
   
    /**
     * @return  Id for the url from the database
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFullUrl() {
        return fullUrl;
    }

    public void setFullUrl(String fullUrl) {
        this.fullUrl = fullUrl;
    }

    public String getShortUrl() {
        return shortUrl;
    }

    public void setShortUrl(String shortUrl) {
        this.shortUrl = shortUrl;
    }
    
    public int getNumberOfRedirects() {
        return numberOfRedirects;
    }

    public void increaseNumberOfRedirects() {
        this.numberOfRedirects++;
    }

    @Override
    public String toString() {
        return "Url{" +
                "id=" + id +
                ", fullUrl='" + fullUrl + '\'' +
                ", shortUrl='" + shortUrl + '\'' +
                '}';
    }
}
