package com.urlshortening.cronjobs;

import java.time.LocalDateTime;
import java.util.List;

import javax.ejb.Schedule;
import javax.ejb.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.urlshortening.model.UrlModel;
import com.urlshortening.services.UrlService;

/*
 * This cron job class resets the count of number of hits to every short url to 0 at midnight
 * This takes care to get the number of hits for that particular day.
 * 
 */

@Singleton
public class ResetShortUrlHitCount {
	Logger logger = LoggerFactory.getLogger(Thread.currentThread().getStackTrace()[1].getClassName());
	 protected final UrlService urlService;

	    
	    public ResetShortUrlHitCount(UrlService urlService) {
	        this.urlService = urlService;
	    }

	
	@Schedule(hour="00", persistent = false)
	public void doWork() {
		logger.info("Reseting the count to 0 at midnight");
		LocalDateTime date = LocalDateTime.now();
		StringBuilder time = new StringBuilder();
		time.append(date.getHour());
		time.append(date.getMinute());
		List<UrlModel> urls = urlService.getAll();
		if(!urls.isEmpty()) {
			for (UrlModel urlModel : urls) {
				urlModel.setNumberOfRedirects(0);
			}
		}
		
	}
	

}
