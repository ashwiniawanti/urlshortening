package com.urlshortening;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.urlshortening.dtos.FullUrlDto;
import com.urlshortening.model.UrlModel;
import com.urlshortening.services.UrlService;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import static org.mockito.ArgumentMatchers.startsWith;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest
@RunWith(SpringRunner.class)
public class UrlControllerTest {
	@Autowired
    private MockMvc mockMvc;
	
	@MockBean
    @Qualifier("urlService")
    private UrlService urlService;
	
	@Test
    public void givenFullUrlReturnStatusOk() throws Exception {
        FullUrlDto fullUrl = new FullUrlDto("https://example.com/foo");

        mockMvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl)))
                .andExpect(status().isOk());
    }
	
	@Test
    public void givenFullUrlReturnJsonWithShortUrlProp() throws Exception {
		FullUrlDto fullUrlObj = new FullUrlDto("https://example.com/foo");

		mockMvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrlObj)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl").exists());
    }

    @Test
    public void givenFullUrlReturnJsonWithShortUrlValueHasHttp() throws Exception {
    	FullUrlDto fullUrl = new FullUrlDto("https://example.com/foo");
        mockMvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl", startsWith("http")));
    }

    @Test
    public void shouldNotInsertFullUrlIfAlreadyExists() throws Exception {
    	FullUrlDto fullUrl = new FullUrlDto("https://example.com/foo");

        String shortUrl1 = mvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl", startsWith("http"))).andReturn().getResponse().getContentAsString();

        String shortUrl2 = mvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl", startsWith("http"))).andReturn().getResponse().getContentAsString();

        Assert.assertEquals(shortUrl1, shortUrl2);
    }

    @Test
    public void shouldNotInsertFullUrlIfDoesNotExist() throws Exception {
    	FullUrlDto fullUrl1 = new FullUrlDto("https://example.com/foo1");
    	FullUrlDto fullUrl2 = new FullUrlDto("https://example.com/foo2");

        String shortUrl1 = mockMvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl1)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl", startsWith("http"))).andReturn().getResponse().getContentAsString();

        String shortUrl2 = mockMvc.perform(post("/shorten")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(fullUrl2)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.shortUrl", startsWith("http"))).andReturn().getResponse().getContentAsString();

        Assert.assertNotEquals(shortUrl1, shortUrl2);
    }

    public static String asJsonString(final Object obj) throws JsonParseException {
        return new ObjectMapper().writeValueAsString(obj);
    }

	
	// Tests the /{shortenString} get endpoint
    @SuppressWarnings("serial")
	@Test
    public void GetUrlStatisticsTest() throws Exception {
    	
        UrlModel url = new UrlModel("http://test.com/test", "test0");

        String testToken = "Basic testToken";
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.set("Authorization", testToken);

       Map<String, Integer> urlMap = new HashMap<String, Integer>() {{
            put(url.getFullUrl(), url.getNumberOfRedirects());
        }};

        given(urlService.getByUrl(url.getFullUrl())).willReturn(urlMap);

        String expectedJson = String.format("{'%s': %s}", url.getFullUrl(), url.getNumberOfRedirects());

        this.mockMvc.perform(
                get( url.getShortUrl())
                .headers(httpHeaders)
            )
            .andExpect(status().isOk())
            .andExpect(content().json(expectedJson));
    }

}
